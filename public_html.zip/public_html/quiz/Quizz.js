function check()
{
 
    var question1 = document.quiz.question1.value;
    var question2 = document.quiz.question2.value;
    var question3 = document.quiz.question3.value;
    var question4 = document.quiz.question4.value;
    var question5 = document.quiz.question5.value;
    var question6 = document.quiz.question6.value;
    var question7 = document.quiz.question7.value;
    var question8 = document.quiz.question8.value;
    var question9 = document.quiz.question9.value;
    var question10 = document.quiz.question10.value;
    var correct = 0;


    if (question1 == "Stormrage") {
        correct++;
}
    if (question2 == "un Prince") {
        correct++;
}   
    if (question3 == "Tony Stark") {
        correct++;
    }
    if (question4 == "139")   {
        correct++;
    }
    if (question5 == "Malfurion")   {
        correct++;
    }
    if (question6 == "Frostmourne")   {
        correct++;
    }
    if (question7 == "Maia")   {
        correct++;
    }
    if (question8 == "James Gordon")   {
        correct++;
    }
    if (question9 == "Batman-Superman")   {
        correct++;
    }
    if (question10 == "Archmage")   {
        correct++;
    }

    
    var pictures = src= ["https://media3.giphy.com/media/xUA7b68hKy839wiVJC/giphy.gif?cid=3640f6095c0a7fef7a7330633632c0d1", "https://media0.giphy.com/media/9xijGdDIMovchalhxN/giphy.gif?cid=3640f6095c0aa5b84b5156674d4e882a", "https://media0.giphy.com/media/s8P1Q6u6LyrRu/giphy.gif?cid=3640f6095c0aa64279487568596f0340"];
    var messages = ["FELICITATION", "Tu doit travaille plus", "C'est une Catastrophe"];
    var range;

    if (correct >= 0 && correct < 5) {
        range = 2;
    }

    if (correct >= 5 && correct <= 9) {
        range = 1;
    }

    if (correct == 10) {
        range = 0;
    }

    document.getElementById("after_submit").style.visibility = "visible";

    document.getElementById("message").innerHTML = messages[range];
    document.getElementById("number_correct").innerHTML = "You got " + correct + " correct.";
    document.getElementById("picture").src = pictures[range];
}